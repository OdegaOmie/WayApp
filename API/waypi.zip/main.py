from app import create_app
app = create_app()
# app.run(host=app.config["FLASK_DOMAIN"], port=app.config["FLASK_PORT"])




